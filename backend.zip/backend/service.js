const express=require('express');
var router=express.Router();
const app=express();
const rp = require('request-promise');
const cheerio = require('cheerio');

module.exports = router.get('/:ref',(req,res)=>{
  var picRefs=[];
  const options = {
      uri: req.query.ref,
      transform: function (body) {
        return cheerio.load(body);
      }
    };
    rp(options)
    .then(($) => {
        var arr=[]
      $('ul[id=thumbs_list_frame]').each((i,element)=>{
        picRefs=element.children.map(child=>child.children[0].next.attribs.href)
        console.log(picRefs)
        return res.status(201).send(picRefs);
      })
      
    })  .catch((err) => {
      console.log('does not work',err);
    });
});
